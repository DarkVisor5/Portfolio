let users = [
    {
      username: 'john_doe',
      email: 'john_doe@example.com',
      password: 'password123',
      favoriteMovies: []
    },
    {
      username: 'jane_doe',
      email: 'jane_doe@example.com',
      password: 'password456',
      favoriteMovies: []
    },
    {
      username: 'movie_fan',
      email: 'movie_fan@example.com',
      password: 'password789',
      favoriteMovies: []
    }
  ];
  module.exports = users;